﻿namespace BinacaWindowApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ddlSymbols = new System.Windows.Forms.ComboBox();
            this.btnPing = new System.Windows.Forms.Button();
            this.lblSymbol = new System.Windows.Forms.Label();
            this.lblAssets = new System.Windows.Forms.Label();
            this.dgvAssets = new System.Windows.Forms.DataGridView();
            this.lblPrice = new System.Windows.Forms.Label();
            this.lblPriceValue = new System.Windows.Forms.Label();
            this.lblPriceList = new System.Windows.Forms.Label();
            this.dgvPrice = new System.Windows.Forms.DataGridView();
            this.btnAllPrices = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAssets)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPrice)).BeginInit();
            this.SuspendLayout();
            // 
            // ddlSymbols
            // 
            this.ddlSymbols.FormattingEnabled = true;
            this.ddlSymbols.Location = new System.Drawing.Point(99, 12);
            this.ddlSymbols.Name = "ddlSymbols";
            this.ddlSymbols.Size = new System.Drawing.Size(168, 21);
            this.ddlSymbols.TabIndex = 0;
            this.ddlSymbols.SelectedIndexChanged += new System.EventHandler(this.ddlSymbols_SelectedIndexChanged);
            // 
            // btnPing
            // 
            this.btnPing.Location = new System.Drawing.Point(273, 8);
            this.btnPing.Name = "btnPing";
            this.btnPing.Size = new System.Drawing.Size(75, 23);
            this.btnPing.TabIndex = 1;
            this.btnPing.Text = "Ping";
            this.btnPing.UseVisualStyleBackColor = true;
            this.btnPing.Click += new System.EventHandler(this.btnPing_Click);
            // 
            // lblSymbol
            // 
            this.lblSymbol.AutoSize = true;
            this.lblSymbol.Location = new System.Drawing.Point(29, 18);
            this.lblSymbol.Name = "lblSymbol";
            this.lblSymbol.Size = new System.Drawing.Size(46, 13);
            this.lblSymbol.TabIndex = 3;
            this.lblSymbol.Text = "Symbols";
            // 
            // lblAssets
            // 
            this.lblAssets.AutoSize = true;
            this.lblAssets.Location = new System.Drawing.Point(29, 43);
            this.lblAssets.Name = "lblAssets";
            this.lblAssets.Size = new System.Drawing.Size(38, 13);
            this.lblAssets.TabIndex = 4;
            this.lblAssets.Text = "Assets";
            // 
            // dgvAssets
            // 
            this.dgvAssets.AllowUserToAddRows = false;
            this.dgvAssets.AllowUserToDeleteRows = false;
            this.dgvAssets.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvAssets.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvAssets.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAssets.Location = new System.Drawing.Point(99, 43);
            this.dgvAssets.Name = "dgvAssets";
            this.dgvAssets.ReadOnly = true;
            this.dgvAssets.Size = new System.Drawing.Size(168, 250);
            this.dgvAssets.TabIndex = 5;
            this.dgvAssets.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dGridViewAssets_ColumnHeaderMouseClick);
            this.dgvAssets.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.dGridViewAssets_DataBindingComplete);
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.Location = new System.Drawing.Point(284, 43);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(31, 13);
            this.lblPrice.TabIndex = 7;
            this.lblPrice.Text = "Price";
            // 
            // lblPriceValue
            // 
            this.lblPriceValue.Location = new System.Drawing.Point(349, 43);
            this.lblPriceValue.Name = "lblPriceValue";
            this.lblPriceValue.Size = new System.Drawing.Size(100, 23);
            this.lblPriceValue.TabIndex = 8;
            // 
            // lblPriceList
            // 
            this.lblPriceList.AutoSize = true;
            this.lblPriceList.Location = new System.Drawing.Point(284, 68);
            this.lblPriceList.Name = "lblPriceList";
            this.lblPriceList.Size = new System.Drawing.Size(47, 13);
            this.lblPriceList.TabIndex = 9;
            this.lblPriceList.Text = "PriceList";
            // 
            // dgvPrice
            // 
            this.dgvPrice.AllowUserToAddRows = false;
            this.dgvPrice.AllowUserToDeleteRows = false;
            this.dgvPrice.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvPrice.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPrice.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPrice.Location = new System.Drawing.Point(352, 68);
            this.dgvPrice.Name = "dgvPrice";
            this.dgvPrice.ReadOnly = true;
            this.dgvPrice.Size = new System.Drawing.Size(243, 225);
            this.dgvPrice.TabIndex = 10;
            this.dgvPrice.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvPrice_ColumnHeaderMouseClick);
            this.dgvPrice.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.dgvPrice_DataBindingComplete);
            // 
            // btnAllPrices
            // 
            this.btnAllPrices.Location = new System.Drawing.Point(363, 8);
            this.btnAllPrices.Name = "btnAllPrices";
            this.btnAllPrices.Size = new System.Drawing.Size(75, 23);
            this.btnAllPrices.TabIndex = 11;
            this.btnAllPrices.Text = "All Prices";
            this.btnAllPrices.UseVisualStyleBackColor = true;
            this.btnAllPrices.Click += new System.EventHandler(this.btnAllPrices_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnAllPrices);
            this.Controls.Add(this.dgvPrice);
            this.Controls.Add(this.lblPriceList);
            this.Controls.Add(this.lblPriceValue);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.dgvAssets);
            this.Controls.Add(this.lblAssets);
            this.Controls.Add(this.lblSymbol);
            this.Controls.Add(this.btnPing);
            this.Controls.Add(this.ddlSymbols);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dgvAssets)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPrice)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox ddlSymbols;
        private System.Windows.Forms.Button btnPing;
        private System.Windows.Forms.Label lblSymbol;
        private System.Windows.Forms.Label lblAssets;
        private System.Windows.Forms.DataGridView dgvAssets;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Label lblPriceValue;
        private System.Windows.Forms.Label lblPriceList;
        private System.Windows.Forms.DataGridView dgvPrice;
        private System.Windows.Forms.Button btnAllPrices;
    }
}

