﻿namespace BinacaWindowApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.ddlSymbols = new System.Windows.Forms.ComboBox();
            this.lblSymbol = new System.Windows.Forms.Label();
            this.lblAssets = new System.Windows.Forms.Label();
            this.dgvAssets = new System.Windows.Forms.DataGridView();
            this.lblPrice = new System.Windows.Forms.Label();
            this.lblPriceValue = new System.Windows.Forms.Label();
            this.lblPriceList = new System.Windows.Forms.Label();
            this.dgvPrice = new System.Windows.Forms.DataGridView();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.lblPriceUpdated = new System.Windows.Forms.Label();
            this.btnStopRefresh = new System.Windows.Forms.Button();
            this.btnStartRefresh = new System.Windows.Forms.Button();
            this.btnShowBalance = new System.Windows.Forms.Button();
            this.rtbAccountDetail = new System.Windows.Forms.RichTextBox();
            this.lblbidprice = new System.Windows.Forms.Label();
            this.lblbidpriceratioValue = new System.Windows.Forms.Label();
            this.btnbidPrice = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAssets)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPrice)).BeginInit();
            this.SuspendLayout();
            // 
            // ddlSymbols
            // 
            this.ddlSymbols.FormattingEnabled = true;
            this.ddlSymbols.Location = new System.Drawing.Point(99, 12);
            this.ddlSymbols.Name = "ddlSymbols";
            this.ddlSymbols.Size = new System.Drawing.Size(168, 21);
            this.ddlSymbols.TabIndex = 0;
            this.ddlSymbols.SelectedIndexChanged += new System.EventHandler(this.DdlSymbols_SelectedIndexChanged);
            // 
            // lblSymbol
            // 
            this.lblSymbol.AutoSize = true;
            this.lblSymbol.Location = new System.Drawing.Point(29, 18);
            this.lblSymbol.Name = "lblSymbol";
            this.lblSymbol.Size = new System.Drawing.Size(46, 13);
            this.lblSymbol.TabIndex = 3;
            this.lblSymbol.Text = "Symbols";
            // 
            // lblAssets
            // 
            this.lblAssets.AutoSize = true;
            this.lblAssets.Location = new System.Drawing.Point(29, 43);
            this.lblAssets.Name = "lblAssets";
            this.lblAssets.Size = new System.Drawing.Size(38, 13);
            this.lblAssets.TabIndex = 4;
            this.lblAssets.Text = "Assets";
            // 
            // dgvAssets
            // 
            this.dgvAssets.AllowUserToAddRows = false;
            this.dgvAssets.AllowUserToDeleteRows = false;
            this.dgvAssets.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvAssets.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvAssets.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAssets.Location = new System.Drawing.Point(99, 43);
            this.dgvAssets.Name = "dgvAssets";
            this.dgvAssets.ReadOnly = true;
            this.dgvAssets.Size = new System.Drawing.Size(168, 250);
            this.dgvAssets.TabIndex = 5;
            this.dgvAssets.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.DGridViewAssets_ColumnHeaderMouseClick);
            this.dgvAssets.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.DGridViewAssets_DataBindingComplete);
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.Location = new System.Drawing.Point(290, 35);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(31, 13);
            this.lblPrice.TabIndex = 7;
            this.lblPrice.Text = "Price";
            // 
            // lblPriceValue
            // 
            this.lblPriceValue.Location = new System.Drawing.Point(327, 33);
            this.lblPriceValue.Name = "lblPriceValue";
            this.lblPriceValue.Size = new System.Drawing.Size(100, 23);
            this.lblPriceValue.TabIndex = 8;
            // 
            // lblPriceList
            // 
            this.lblPriceList.AutoSize = true;
            this.lblPriceList.Location = new System.Drawing.Point(472, 72);
            this.lblPriceList.Name = "lblPriceList";
            this.lblPriceList.Size = new System.Drawing.Size(47, 13);
            this.lblPriceList.TabIndex = 9;
            this.lblPriceList.Text = "PriceList";
            // 
            // dgvPrice
            // 
            this.dgvPrice.AllowUserToAddRows = false;
            this.dgvPrice.AllowUserToDeleteRows = false;
            this.dgvPrice.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvPrice.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPrice.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPrice.Location = new System.Drawing.Point(545, 68);
            this.dgvPrice.Name = "dgvPrice";
            this.dgvPrice.ReadOnly = true;
            this.dgvPrice.Size = new System.Drawing.Size(243, 225);
            this.dgvPrice.TabIndex = 10;
            this.dgvPrice.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvPrice_ColumnHeaderMouseClick);
            this.dgvPrice.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.DgvPrice_DataBindingComplete);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.Timer1_Tick);
            // 
            // lblPriceUpdated
            // 
            this.lblPriceUpdated.Location = new System.Drawing.Point(591, 35);
            this.lblPriceUpdated.Name = "lblPriceUpdated";
            this.lblPriceUpdated.Size = new System.Drawing.Size(211, 30);
            this.lblPriceUpdated.TabIndex = 12;
            this.lblPriceUpdated.Text = "Prices last Updated";
            // 
            // btnStopRefresh
            // 
            this.btnStopRefresh.Location = new System.Drawing.Point(539, 10);
            this.btnStopRefresh.Name = "btnStopRefresh";
            this.btnStopRefresh.Size = new System.Drawing.Size(110, 23);
            this.btnStopRefresh.TabIndex = 13;
            this.btnStopRefresh.Text = "Stop Price Refresh";
            this.btnStopRefresh.UseVisualStyleBackColor = true;
            this.btnStopRefresh.Click += new System.EventHandler(this.BtnStopRefresh_Click);
            // 
            // btnStartRefresh
            // 
            this.btnStartRefresh.Location = new System.Drawing.Point(407, 8);
            this.btnStartRefresh.Name = "btnStartRefresh";
            this.btnStartRefresh.Size = new System.Drawing.Size(112, 23);
            this.btnStartRefresh.TabIndex = 14;
            this.btnStartRefresh.Text = "Start Price Refresh";
            this.btnStartRefresh.UseVisualStyleBackColor = true;
            this.btnStartRefresh.Click += new System.EventHandler(this.BtnStartRefresh_Click);
            // 
            // btnShowBalance
            // 
            this.btnShowBalance.Location = new System.Drawing.Point(32, 320);
            this.btnShowBalance.Name = "btnShowBalance";
            this.btnShowBalance.Size = new System.Drawing.Size(110, 23);
            this.btnShowBalance.TabIndex = 15;
            this.btnShowBalance.Text = "Show Balance";
            this.btnShowBalance.UseVisualStyleBackColor = true;
            this.btnShowBalance.Click += new System.EventHandler(this.btnShowBalance_Click);
            // 
            // rtbAccountDetail
            // 
            this.rtbAccountDetail.Location = new System.Drawing.Point(167, 320);
            this.rtbAccountDetail.Name = "rtbAccountDetail";
            this.rtbAccountDetail.Size = new System.Drawing.Size(591, 96);
            this.rtbAccountDetail.TabIndex = 16;
            this.rtbAccountDetail.Text = "";
            // 
            // lblbidprice
            // 
            this.lblbidprice.AutoSize = true;
            this.lblbidprice.Location = new System.Drawing.Point(290, 89);
            this.lblbidprice.Name = "lblbidprice";
            this.lblbidprice.Size = new System.Drawing.Size(100, 13);
            this.lblbidprice.TabIndex = 17;
            this.lblbidprice.Text = "Bid price ratio value";
            // 
            // lblbidpriceratioValue
            // 
            this.lblbidpriceratioValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblbidpriceratioValue.ForeColor = System.Drawing.Color.GreenYellow;
            this.lblbidpriceratioValue.Location = new System.Drawing.Point(290, 121);
            this.lblbidpriceratioValue.Name = "lblbidpriceratioValue";
            this.lblbidpriceratioValue.Size = new System.Drawing.Size(236, 61);
            this.lblbidpriceratioValue.TabIndex = 18;
            // 
            // btnbidPrice
            // 
            this.btnbidPrice.Location = new System.Drawing.Point(278, 7);
            this.btnbidPrice.Name = "btnbidPrice";
            this.btnbidPrice.Size = new System.Drawing.Size(112, 23);
            this.btnbidPrice.TabIndex = 19;
            this.btnbidPrice.Text = "Bid Price Ratio";
            this.btnbidPrice.UseVisualStyleBackColor = true;
            this.btnbidPrice.Click += new System.EventHandler(this.btnbidPrice_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnbidPrice);
            this.Controls.Add(this.lblbidpriceratioValue);
            this.Controls.Add(this.lblbidprice);
            this.Controls.Add(this.rtbAccountDetail);
            this.Controls.Add(this.btnShowBalance);
            this.Controls.Add(this.btnStartRefresh);
            this.Controls.Add(this.btnStopRefresh);
            this.Controls.Add(this.lblPriceUpdated);
            this.Controls.Add(this.dgvPrice);
            this.Controls.Add(this.lblPriceList);
            this.Controls.Add(this.lblPriceValue);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.dgvAssets);
            this.Controls.Add(this.lblAssets);
            this.Controls.Add(this.lblSymbol);
            this.Controls.Add(this.ddlSymbols);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "Test Form";
            ((System.ComponentModel.ISupportInitialize)(this.dgvAssets)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPrice)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox ddlSymbols;
        private System.Windows.Forms.Label lblSymbol;
        private System.Windows.Forms.Label lblAssets;
        private System.Windows.Forms.DataGridView dgvAssets;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Label lblPriceValue;
        private System.Windows.Forms.Label lblPriceList;
        private System.Windows.Forms.DataGridView dgvPrice;
        private System.Windows.Forms.Label lblPriceUpdated;
        private System.Windows.Forms.Button btnStopRefresh;
        private System.Windows.Forms.Button btnStartRefresh;
        private System.Windows.Forms.Button btnShowBalance;
        private System.Windows.Forms.RichTextBox rtbAccountDetail;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lblbidprice;
        private System.Windows.Forms.Label lblbidpriceratioValue;
        private System.Windows.Forms.Button btnbidPrice;
    }
}

