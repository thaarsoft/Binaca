﻿using System;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Binance;

namespace BinacaWindowApp
{
    public partial class Form1 : Form
    {
        BinanceApi api ;
        CancellationTokenSource cts;
        public Form1()
        {
            InitializeComponent();
            api = new BinanceApi();
            fillSymbols();
            fillAssets();
            cts = new CancellationTokenSource();
            //fillPrices();
        }
        private async Task fillAllPrices()
        {
            var prices = await api.GetPricesAsync(cts.Token);

            var dt = new DataTable();
            dt.Columns.Add("Symbol");
            dt.Columns.Add("Value");
            foreach (var price in prices)
            {
                dt.Rows.Add(price.Symbol,price.Value);
            }

            dgvPrice.DataSource = dt;
            //dgvPrice.DataSource = prices;
        }
        private void fillPrices()
        {
            try
            {
                string symbol = ddlSymbols.SelectedItem.ToString();
                if (!string.IsNullOrWhiteSpace(symbol))
                {
                    var price = api.GetPriceAsync(symbol);
                    lblPriceValue.Text = price.Result.ToString();
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            
        }

        private void btnPing_Click(object sender, EventArgs e)
        {
            PingFunction();
        }

        private static async Task PingFunction()
        {
            var api = new BinanceApi();
            var result = await api.PingAsync().ConfigureAwait(false);
            MessageBox.Show("Binance api is running:" + result.ToString());
        }
        private void fillSymbols()
        {
            var symbols = Symbol.Cache.GetAll().OrderBy(s => s.ToString()).ToList<Symbol>();
            ddlSymbols.DataSource = symbols;
            
        }
        private void fillAssets()
        {
            var list = Asset.Cache.GetAll().OrderBy(a => a.Symbol).ToList();

            var dt = new DataTable();
            dt.Columns.Add("Symbol");
            foreach (var user in list)
                dt.Rows.Add(user.Symbol);
            dgvAssets.DataSource = dt;
        }

        private void dGridViewAssets_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            DataGridViewColumn newColumn = dgvAssets.Columns[e.ColumnIndex];
            DataGridViewColumn oldColumn = dgvAssets.SortedColumn;
            ListSortDirection direction;

            // If oldColumn is null, then the DataGridView is not sorted.
            if (oldColumn != null)
            {
                // Sort the same column again, reversing the SortOrder.
                if (oldColumn == newColumn &&
                    dgvAssets.SortOrder == SortOrder.Ascending)
                {
                    direction = ListSortDirection.Descending;
                }
                else
                {
                    // Sort a new column and remove the old SortGlyph.
                    direction = ListSortDirection.Ascending;
                    oldColumn.HeaderCell.SortGlyphDirection = SortOrder.None;
                }
            }
            else
            {
                direction = ListSortDirection.Ascending;
            }

            // Sort the selected column.
            dgvAssets.Sort(newColumn, direction);
            newColumn.HeaderCell.SortGlyphDirection =
                direction == ListSortDirection.Ascending ?
                SortOrder.Ascending : SortOrder.Descending;
        }

        private void dGridViewAssets_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            foreach (DataGridViewColumn column in dgvAssets.Columns)
            {
                column.SortMode = DataGridViewColumnSortMode.Programmatic;
            }
        }

        private void ddlSymbols_SelectedIndexChanged(object sender, EventArgs e)
        {
            fillPrices();
        }

       

        private void btnAllPrices_Click(object sender, EventArgs e)
        {
            fillAllPrices();
        }
        private void dgvPrice_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            DataGridViewColumn newColumn = dgvPrice.Columns[e.ColumnIndex];
            DataGridViewColumn oldColumn = dgvPrice.SortedColumn;
            ListSortDirection direction;

            // If oldColumn is null, then the DataGridView is not sorted.
            if (oldColumn != null)
            {
                // Sort the same column again, reversing the SortOrder.
                if (oldColumn == newColumn &&
                    dgvPrice.SortOrder == SortOrder.Ascending)
                {
                    direction = ListSortDirection.Descending;
                }
                else
                {
                    // Sort a new column and remove the old SortGlyph.
                    direction = ListSortDirection.Ascending;
                    oldColumn.HeaderCell.SortGlyphDirection = SortOrder.None;
                }
            }
            else
            {
                direction = ListSortDirection.Ascending;
            }

            // Sort the selected column.
            dgvPrice.Sort(newColumn, direction);
            newColumn.HeaderCell.SortGlyphDirection =
                direction == ListSortDirection.Ascending ?
                SortOrder.Ascending : SortOrder.Descending;
        }
        private void dgvPrice_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            foreach (DataGridViewColumn column in dgvPrice.Columns)
            {
                column.SortMode = DataGridViewColumnSortMode.Programmatic;
            }
        }
    }
}
