﻿using System;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Binance;
using System.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System.Text;
using Binance.Cache;
using Binance.WebSocket;
using Newtonsoft.Json.Linq;
using Binance.Api;

namespace BinacaWindowApp
{
    public partial class Form1 : Form
    {
        BinanceApi api ;
        CancellationTokenSource cts;
        public static IBinanceApiUser User;
        public static IServiceProvider ServiceProvider;
        public IBinanceHttpClient HttpClient { get; }
        //public static float BidToAskRatioNumber;
        public Form1()
        {
            InitializeComponent();
            api = new BinanceApi();
            FillSymbols();
            FillAssets();
            cts = new CancellationTokenSource();
            btnStartRefresh.Enabled = false;
            string apiKey = ConfigurationManager.AppSettings["apiKey"].ToString();
            string apiSecret = ConfigurationManager.AppSettings["ApiSecret"].ToString();
            ServiceProvider = new ServiceCollection()
                .AddBinance(useSingleCombinedStream: true) 
                .AddOptions()
                .BuildServiceProvider();
            if (!string.IsNullOrEmpty(apiKey))
            {
                User = ServiceProvider
                    .GetService<IBinanceApiUserProvider>()
                    .CreateUser(apiKey, apiSecret);
            }
           
        }
        private async Task FillAllPrices()
        {
            
            var prices = await api.GetPricesAsync(cts.Token);
            var dt = new DataTable();
            dt.Columns.Add("Symbol");
            dt.Columns.Add("Value", typeof(double));
            //dt.Columns.Add("BidToAskRatio", typeof(float));
            //var allSymbols = Symbol.Cache.GetAll().OrderBy(s => s.ToString()).ToList<Symbol>();
           
           foreach (var price in prices)
            {
                //if (allSymbols.Exists(i => (i.BaseAsset + i.QuoteAsset) == price.Symbol))
                //{
                //    int iSymbol = allSymbols.FindIndex(i => (i.BaseAsset + i.QuoteAsset) == price.Symbol);
                //    string strPair1 = allSymbols[iSymbol].BaseAsset + "_" + allSymbols[iSymbol].QuoteAsset;

                //    BidToAskRatio(strPair1);
                //}

                //dt.Rows.Add(price.Symbol, price.Value,BidToAskRatioNumber);
                dt.Rows.Add(price.Symbol, price.Value);
            }

            dgvPrice.DataSource = dt;
            dgvPrice.Columns["Value"].DefaultCellStyle.Format = "N7";
            //dgvPrice.Columns["BidToAskRatio"].DefaultCellStyle.Format = "N7";
            lblPriceUpdated.Text = "Prices last Updated " + DateTime.Now;
        }
        delegate void SetTextCallback(string text);

        private void SetText(string text)
        {
            // InvokeRequired required compares the thread ID of the
            // calling thread to the thread ID of the creating thread.
            // If these threads are different, it returns true.
            if (this.lblPriceValue.InvokeRequired)
            {
                SetTextCallback d = new SetTextCallback(SetText);
                this.Invoke(d, new object[] { text });
            }
            else
            {
                this.lblPriceValue.Text = text;
            }
        }
        private async void FillPrice()
        {
            try
            {
                string symbol = ddlSymbols.SelectedItem.ToString();
                if (!string.IsNullOrWhiteSpace(symbol))
                {
                    var price = await api.GetPriceAsync(symbol).ConfigureAwait(false);
                    SetText(price.Value.ToString());
                    //lblPriceValue.Text = price.Value.ToString();
                    //lblPriceValue.Text = price.Result.ToString();
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            
        }

       
       private void FillSymbols()
        {
            var symbols = Symbol.Cache.GetAll().OrderBy(s => s.ToString()).ToList<Symbol>();
     
            ddlSymbols.DataSource = symbols;
            
        }
        private void FillAssets()
        {
           var list = Asset.Cache.GetAll().OrderBy(a => a.Symbol).ToList();

            var dt = new DataTable();
            dt.Columns.Add("Symbol");
            foreach (var user in list)
                dt.Rows.Add(user.Symbol);
            dgvAssets.DataSource = dt;
        }

        private void DGridViewAssets_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            DataGridViewColumn newColumn = dgvAssets.Columns[e.ColumnIndex];
            DataGridViewColumn oldColumn = dgvAssets.SortedColumn;
            ListSortDirection direction;

            // If oldColumn is null, then the DataGridView is not sorted.
            if (oldColumn != null)
            {
                // Sort the same column again, reversing the SortOrder.
                if (oldColumn == newColumn &&
                    dgvAssets.SortOrder == SortOrder.Ascending)
                {
                    direction = ListSortDirection.Descending;
                }
                else
                {
                    // Sort a new column and remove the old SortGlyph.
                    direction = ListSortDirection.Ascending;
                    oldColumn.HeaderCell.SortGlyphDirection = SortOrder.None;
                }
            }
            else
            {
                direction = ListSortDirection.Ascending;
            }

            // Sort the selected column.
            dgvAssets.Sort(newColumn, direction);
            newColumn.HeaderCell.SortGlyphDirection =
                direction == ListSortDirection.Ascending ?
                SortOrder.Ascending : SortOrder.Descending;
        }

        private void DGridViewAssets_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            foreach (DataGridViewColumn column in dgvAssets.Columns)
            {
                column.SortMode = DataGridViewColumnSortMode.Programmatic;
            }
        }

        private void DdlSymbols_SelectedIndexChanged(object sender, EventArgs e)
        {
           FillPrice();
        }

       

        private void dgvPrice_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            DataGridViewColumn newColumn = dgvPrice.Columns[e.ColumnIndex];
            DataGridViewColumn oldColumn = dgvPrice.SortedColumn;
            ListSortDirection direction;

            // If oldColumn is null, then the DataGridView is not sorted.
            if (oldColumn != null)
            {
                // Sort the same column again, reversing the SortOrder.
                if (oldColumn == newColumn &&
                    dgvPrice.SortOrder == SortOrder.Ascending)
                {
                    direction = ListSortDirection.Descending;
                }
                else
                {
                    // Sort a new column and remove the old SortGlyph.
                    direction = ListSortDirection.Ascending;
                    oldColumn.HeaderCell.SortGlyphDirection = SortOrder.None;
                }
            }
            else
            {
                direction = ListSortDirection.Ascending;
            }

            // Sort the selected column.
            dgvPrice.Sort(newColumn, direction);
            newColumn.HeaderCell.SortGlyphDirection =
                direction == ListSortDirection.Ascending ?
                SortOrder.Ascending : SortOrder.Descending;
        }
        private void DgvPrice_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            foreach (DataGridViewColumn column in dgvPrice.Columns)
            {
                column.SortMode = DataGridViewColumnSortMode.Programmatic;
            }
        }

        private async void Timer1_Tick(object sender, EventArgs e)
        {
            await FillAllPrices().ConfigureAwait(false);
        }

        private void BtnStopRefresh_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            btnStopRefresh.Enabled = false;
            btnStartRefresh.Enabled = true;
        }

        private void BtnStartRefresh_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            btnStartRefresh.Enabled = false;
            btnStopRefresh.Enabled = true;
        }
        
        private async void ShowBalance()
        {
            var account = await api.GetAccountInfoAsync(User, 1000000, token:cts.Token).ConfigureAwait(false);
            string canTrade = (account.Status.CanTrade ? "Yes" : "No").PadLeft(3);
            string canWithdraw = (account.Status.CanWithdraw ? "Yes" : "No").PadLeft(3);
            string canDeposit = (account.Status.CanDeposit ? "Yes" : "No").PadLeft(3);
             StringBuilder sbAccount = new StringBuilder();
            sbAccount.Append("Maker Commission: ").Append(account.Commissions.Maker.ToString()).Append(" bips ").Append("(")
                .Append(Convert.ToSingle(account.Commissions.Maker/100.0)).Append("%)").Append(Environment.NewLine)
                .Append("Taker Commission: ").Append(account.Commissions.Taker.ToString()).Append(" bips ").Append("(")
                .Append(account.Commissions.Taker / 100.0).Append("%)").Append(Environment.NewLine)
                .Append("Buyer Commission: ").Append(account.Commissions.Buyer.ToString()).Append(" bips ").Append("(")
                .Append(account.Commissions.Buyer / 100.0).Append("%)").Append(Environment.NewLine)
                .Append("Seller Commission: ").Append(account.Commissions.Seller.ToString()).Append(" bips ").Append("(")
                .Append(account.Commissions.Seller / 100.0).Append("%)").Append(Environment.NewLine)
                .Append("Can Trade: ").Append(canTrade).Append(Environment.NewLine)
                .Append("Can Withdraw: ").Append(canWithdraw).Append(Environment.NewLine)
                .Append("Can Deposit: ").Append(canDeposit).Append(Environment.NewLine)
                .Append("Balances (only amounts > 0):").Append(Environment.NewLine);
            foreach (var balance in account.Balances)
            {
                //if (balance.Free > 0 || balance.Locked > 0)
                //{
                    sbAccount.Append("Asset: ").Append(balance.Asset).Append("- Free: ").Append(balance.Free).Append("- Locked: ").Append(balance.Locked).Append(Environment.NewLine);
                //}
            }

            rtbAccountDetail.Invoke((MethodInvoker)delegate
            {
                rtbAccountDetail.Text = sbAccount.ToString();
                btnShowBalance.Enabled = true;
            });
            
        }

        private void btnShowBalance_Click(object sender, EventArgs e)
        {
            try
            {
                btnShowBalance.Enabled = false;
                ShowBalance();
                //GetAccountInfoAsync()
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            
        }
        
         void BidToAskRatio(string Pairs)
        {
            
            // Initialize web socket cache (with automatic streaming).
            var webSocketCache = new DepthWebSocketCache();
            webSocketCache.Subscribe(Pairs, evt =>
            {
                // Get symbol from cache (update cache if a symbol is missing).
                var symbol = Symbol.Cache.Get(evt.OrderBook.Symbol);

                var minBidPrice = evt.OrderBook.Bids.Last().Price;
                var maxAskPrice = evt.OrderBook.Asks.Last().Price;

               lblbidpriceratioValue.Invoke((MethodInvoker)delegate
                {
                    lblbidpriceratioValue.Text = (evt.OrderBook.Depth(minBidPrice) / evt.OrderBook.Depth(maxAskPrice)).ToString();
                });
                //BidToAskRatioNumber = Convert.ToSingle(sbResult.ToString());
            });
        }

        private void btnbidPrice_Click(object sender, EventArgs e)
        {
            if(ddlSymbols.SelectedItem!=null)
            {
                var selectedItem = (Symbol)ddlSymbols.SelectedItem;
                string paris = selectedItem.BaseAsset + "_" + selectedItem.QuoteAsset;

                BidToAskRatio(paris);
                //lblbidpriceratioValue.Text = BidToAskRatioNumber.ToString();
            }            
        }
    }
}
